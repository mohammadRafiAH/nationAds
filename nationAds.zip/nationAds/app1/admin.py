from django.contrib import admin
from .models import Franchisees,Clients,Agency,Buses,RevenueFormula,CreateOrder,FranchiseePayment,BusFranchisee,Organization,GstPayment,CompanyRevenue,ServiceCharge,AgencyPayment ,installmentsPayment,CollectData

admin.site.register(Franchisees)
admin.site.register(Clients)
admin.site.register(Agency)
admin.site.register(Buses)
admin.site.register(RevenueFormula)
admin.site.register(CreateOrder)
admin.site.register(FranchiseePayment)
admin.site.register(BusFranchisee)
admin.site.register(Organization)
admin.site.register(GstPayment)
admin.site.register(CompanyRevenue)
admin.site.register(ServiceCharge)
admin.site.register(AgencyPayment)
admin.site.register(installmentsPayment)
admin.site.register(CollectData)
