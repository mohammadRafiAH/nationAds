function toggleMenu() {
    let toggle = document.querySelector(".toggle");
    let navigation = document.querySelector(".navigation");
    let main = document.querySelector(".main");
    let orderMain = document.querySelector(".order-main");
    let franchiseeMain = document.querySelector("#franchisee-main");
    let addClientMain = document.querySelector(".add-client-main");
    let busMain = document.querySelector(".bus-main");
    let organisationMain = document.querySelector(".organisation-main");
    let gstMain = document.querySelector(".gst-main");
    let companyRevenueMain = document.querySelector(
      ".company-revenue-main"
    );
    let serverChargeMain = document.querySelector(".server-charge-main");
    let agencyMain = document.querySelector(".agency-main");
    let settingsMain = document.querySelector(".settings-main");

    toggle.classList.toggle("active");
    navigation.classList.toggle("active");
    main.classList.toggle("active");
    orderMain.classList.toggle("active");
    franchiseeMain.classList.toggle("active");
    addClientMain.classList.toggle("active");
    busMain.classList.toggle("active");
    organisationMain.classList.toggle("active");
    gstMain.classList.toggle("active");
    companyRevenueMain.classList.toggle("active");
    serverChargeMain.classList.toggle("active");
    agencyMain.classList.toggle("active");
    settingsMain.classList.toggle("active");
  }


  /*

  let Normal = document.querySelector('.Normal');  
  let byOtherFranchise = document.querySelector('.BY-other-Franchise');
  let byAdAgency = document.querySelector('.By-ad-Agency');

  let normalDynamicColumn = document.querySelector('.Normal-dynamic-column');
  let otherFranchiseDynamicColumn = document.querySelector('.OtherFranchise-dynamic-column');
  let agencyDynamicColumn = document.querySelector('.Agency-dynamic-column');
  

  Normal.addEventListener('click', function(){
    Normal.add(normalDynamicColumn);
    normalDynamicColumn.classList.style.display="block";
  });
  byOtherFranchise.addEventListener('click', function(){
    byOtherFranchise.add(otherFranchiseDynamicColumn)
    otherFranchiseDynamicColumn.classList.style.display="block";
  });
  byAdAgency.addEventListener('click', function(){
    byAdAgency.add(agencyDynamicColumn);
    agencyDynamicColumn.classList.style.display="block";

  });  


  */

