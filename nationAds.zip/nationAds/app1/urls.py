from django.urls import path
from . import views

urlpatterns =[
    path("",views.index,name='index'),
    path("orders",views.orders,name='orders'),
    path("deleteOrders/<int:order_id>/",views.deleteOrders,name='deleteOrders'),
    
     #franchisee 
    path("franchisees",views.franchisees,name='franchisees'),
    path('delete/<str:franchisee_code>/', views.delete_franchisee, name='delete_franchisee'),
    path("franchiseePaymentView/<str:franchisee_name>/",views.franchiseePaymentView,name='franchiseePaymentView'),
    
    
    path("client",views.client,name='client'),
    path("deleteClient/<str:client_name>/",views.deleteClient,name='deleteClient'),   
    path("clientViews",views.clientViews,name='clientViews'),
    
    path("buses",views.buses,name='buses'),
    path("busesListView",views.busesListView,name='busesListView'),
    path("paymentBusesListView/<str:bus_owner_name>/",views.paymentBusesListView,name='paymentBusesListView'),
    
    
    path("organization",views.organization,name='organization'),
    
    path("gst",views.gst,name='gst'),
    
    path("companyRevenue",views.companyRevenue,name='companyRevenue'),
    
    path("serviceCharge",views.serviceCharge,name='serviceCharge'),
    
    path("companyAsAgency",views.companyAsAgency,name='companyAsAgency'),
    path("deleteAgency/<str:agency_name>/",views.deleteAgency,name='deleteAgency'),
    
    
    path("agencyPaymentsView",views.agencyPaymentsView,name='agencyPaymentsView'),
    
    path("revenueFormula",views.revenueFormula,name='revenueFormula'),
]
