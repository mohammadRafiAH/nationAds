from typing import Any
from django.db import models


class Franchisees(models.Model):
    # f_id = models.IntegerField(null=True)
    f_code = models.CharField(max_length=255,null=True)
    f_name = models.CharField(max_length=255,null=True)
    f_phone_number = models.IntegerField(null=True)
    f_address= models.TextField(null=True)

    def __str__(self):
        return self.f_name

class Clients(models.Model):
    email = models.EmailField(null=True)
    name = models.CharField(max_length=255,null=True)
    address = models.CharField(max_length=255,null=True)
    phone = models.IntegerField(null=True)
    gst= models.TextField(null=True)

    def __str__(self):
        return self.name
    
class Agency(models.Model):
    agencyName = models.CharField(max_length=255,null=True)

    def __str__(self):
        return self.agencyName
    
    
class Buses(models.Model):
    franchisee_Or_agency = models.CharField(max_length=255,null=True)
    captured_type_value = models.CharField(max_length=255,null=True)
    bus_name = models.CharField(max_length=255,null=True)
    district = models.CharField(max_length=255,null=True)
    owner_name = models.CharField(max_length=255,null=True)
    bus_route= models.CharField(max_length=255,null=True)
    vehicle_number= models.CharField(max_length=255,null=True)
    

    def __str__(self):
        return self.bus_name
    
        
    
class RevenueFormula(models.Model):
    normal_company = models.IntegerField(null=False,default=0)
    normal_busOwner = models.IntegerField(null=False,default=0)
    normal_busOrganization = models.IntegerField(null=False,default=0)
    normal_franchisee = models.IntegerField(null=False,default=0)
    
    other_fr_company = models.IntegerField(null=False,default=0)
    other_fr_adFranchisee = models.IntegerField(null=False,default=0)
    other_fr_busOwner = models.IntegerField(null=False,default=0)
    other_fr_busOrganization = models.IntegerField(null=False,default=0)
    other_fr_franchisee = models.IntegerField(null=False,default=0)
    other_fr_service = models.IntegerField(null=False,default=0)
    
    agency_company = models.IntegerField(null=False,default=0)
    agency_bus_owner = models.IntegerField(null=False,default=0)
    agency_bus_organization = models.FloatField(null=False,default=0)
    agency_franchisee = models.FloatField(null=False,default=0)
    agency_agency = models.IntegerField(null=False,default=0)
    
    duration15s = models.IntegerField(null=False,default=0)
    duration30s = models.IntegerField(null=False,default=0)
    duration45s = models.IntegerField(null=False,default=0)
    duration60s = models.IntegerField(null=False,default=0)
    
    def __str__(self):
        return "revenue formulation"
    
    
class CreateOrder(models.Model):
    ad_capture_by_type = models.CharField(max_length=200,null=False)
    ad_capture_by_value = models.CharField(max_length=200,null=False)
    adVal = models.IntegerField(null=False)
    len_of_selected_buses = models.IntegerField(null=False)
    bus_type = models.JSONField(null=False,default=dict)
    bus_fr_or_agency = models.JSONField(null=False)
    bus_owners = models.JSONField(null=False,default=dict)
    start_date = models.DateTimeField(null=False)
    end_date = models.DateTimeField(null=False)
    diff_date = models.IntegerField(null=False)
    client_name = models.CharField(max_length=255,null=False)
    ad_name = models.CharField(max_length=255,null=False)
    discount_amount = models.IntegerField(null=False)
    gst_check_inputVal = models.CharField(max_length=255,null=False)
    advance_amount = models.IntegerField(null=False)
    ad_making_charge = models.IntegerField(null=False)
    total_payable_amount = models.IntegerField(null=False)
    totalCharge_show = models.IntegerField(null=False,default=0)
    
    def __str__(self):
        return f"{self.ad_name} {self.start_date} {self.end_date}"
    
class installmentsPayment(models.Model):
    order_id = models.IntegerField(null=True,default=0)
    ad_payment = models.IntegerField(null=False, default=0)
    invoices_number = models.CharField(max_length=255,null=False,default='')
    text = models.CharField(max_length=255,null=False,default='')
    date = models.CharField(max_length=255,null=False,default='')
    def __str__(self):
        return  f" id = {self.order_id} installment payment = {self.ad_payment} invoice number = {self.invoices_number}"
    
    
    
class FranchiseePayment(models.Model):
       fr_name = models.CharField(max_length=255,null=False,default='')
       date = models.DateField(auto_now_add=False, null=False,default=True)
       ad_name = models.CharField(max_length=255,null=False,default=True)
       formula_type = models.CharField(max_length=255,null=False,default=True)
       amount = models.IntegerField(null=False,default=True)
       status = models.CharField(max_length=255,null=False,default=True)
       actions = models.CharField(max_length=255,null=False,default=True)
       
       def __str__(self):
           return self.fr_name

class BusFranchisee(models.Model):
      busFranchisee_name = models.CharField(max_length=255,null=False,default='')
      district = models.CharField(max_length=255,null=False,default='')
      bus_name = models.CharField(max_length=255,null=False,default='')
      vehicle_number = models.CharField(max_length=255,null=False,default='')
      formula_type = models.CharField(max_length=255,null=False,default='')
      amount = models.IntegerField(null=False,default=0)
      status = models.CharField(max_length=255,null=False, default='')
      actions = models.CharField(max_length=255,null=False, default='')
      
      
             
class Organization(models.Model):
    start_date = models.DateTimeField(auto_now_add=False)       
    end_date = models.DateTimeField(auto_now_add=False)
    ad_name = models.CharField(max_length=255,null=False,default='')
    formula_type = models.CharField(max_length=255,null=False,default='')
    amount = models.IntegerField(null=False,default=0)
    
    
class GstPayment(models.Model):
    client_name = models.CharField(max_length=255,null=False,default='')
    ad_name = models.CharField(max_length=255,null=False,default='')
    taxable_amount = models.IntegerField(null=False,default=0)
    Gst_amount = models.IntegerField(null=False,default=0)
    total_amount_with_gst =models.IntegerField(null=False,default=0)
    status = models.CharField(max_length=255,null=False,default='')
    actions = models.CharField(max_length=255,null=False, default='') 

class CompanyRevenue(models.Model):
    ad_name = models.CharField(max_length=255,null=False,default='')
    ad_captured_by = models.CharField(max_length=255,null=False,default='')
    formula_type = models.CharField(max_length=255,null=False,default='')
    amount = models.IntegerField(null=False,default=0)
    start_date = models.DateField(auto_now_add=False,default=True)
    date_of_payment = models.DateField(auto_now_add=False,default=True)
    
    
class ServiceCharge(models.Model):
   date = models.DateField(auto_now_add=False,default=True)
   amount = models.IntegerField(null=False,default=0)
   ad_name = models.CharField(max_length=255,null=False,default='')
   

class AgencyPayment(models.Model):
    date = models.DateField(auto_now_add=False,default=True)
    ad_name = models.CharField(max_length=255,null=False,default='')
    amount = models.IntegerField(null=False,default=0)
    status = models.IntegerField(null=False,default=0)
    actions = models.CharField(max_length=255, null=False,default='')
       
                    
class CollectData(models.Model):
    fr_matching_entries_normal = models.JSONField(null=False,default=dict)
    bus_owner_matching_entries_normal = models.JSONField(null=False,default=dict)
    organization_matching_entries_normal = models.JSONField(null=False,default=dict)
    companyRevenue_matching_entries_normal = models.JSONField(null=False,default=dict)
    
    
    bus_fr_other_entries = models.JSONField(null=False,default=dict)
    ad_fr_other_entries = models.JSONField(null=False,default=dict)
    bus_owner_fr_other_entries = models.JSONField(null=False,default=dict)
    organization_fr_other_entries = models.JSONField(null=False,default=dict)
    companyRevenue_fr_other_entries = models.JSONField(null=False,default=dict)
    service_fr_other_entries = models.JSONField(null=False,default=dict)
    
    
    agency_matching_entries = models.JSONField(null=False,default=dict)
    company_agency_matching_entries = models.JSONField(null=False,default=dict)
    bus_owner_agency_matching_entries = models.JSONField(null=False,default=dict)
    organization_agency_matching_entries = models.JSONField(null=False,default=dict)
    bus_franchisee_agency_matching_entries = models.JSONField(null=False,default=dict)