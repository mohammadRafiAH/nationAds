from django.shortcuts import render,redirect
from .models import Franchisees,Clients,Agency,Buses,RevenueFormula,CreateOrder,FranchiseePayment,BusFranchisee,installmentsPayment,CollectData,GstPayment
from django.views.decorators.csrf import csrf_exempt
from django.core.exceptions import ValidationError
from django.http import HttpResponse
from datetime import datetime
from django.utils.dateparse import parse_date
from django.utils import timezone

@csrf_exempt
def index(request):
    #Initial fetch for options
    franchisee_options = Franchisees.objects.all()
    agency_options = Agency.objects.all()

    # Default values
    ad_capture = "franchisee"
    ad_capture_val = franchisee_options
    error_message = None

    if request.method == 'POST':
        try:
            ad_capture_by_type = request.POST.get('ad-captured-by-type')
            ad_capture_by_val = request.POST.get('captured-by-id')
            adVal = request.POST.get('ad-duration')
            # print('fr or agency = ', ad_capture_by_type)
            # print('fr or agency name = ', ad_capture_by_val)
            # print('ad Value = ', adVal)

            # Select bus when user checks box
            selected_buses = request.POST.getlist('selected_buses')
            len_of_selected_buses = len(selected_buses)
            # print("bus", len_of_selected_buses)
            bus_types = {}
            bus_fr_or_agency = {}
            bus_owners = {}

            for bus_id in selected_buses:
                bus = Buses.objects.get(id=bus_id)
                bus_type = bus.franchisee_Or_agency
                bus_fr_or_agency_name = bus.captured_type_value
                bus_owner = bus.owner_name
                bus_types[bus_id] = bus_type
                bus_fr_or_agency[bus_id] = bus_fr_or_agency_name
                bus_owners[bus_id] = bus_owner

            # print(bus_types)
            # print(bus_fr_or_agency)
            # print(bus_owners)

            # Start date and end date
            start_date_str = request.POST.get('ad-start-date')
            end_date_str = request.POST.get('ad-end-date')
            diff_date = None
            if start_date_str and end_date_str:
                start_date = parse_date(start_date_str)
                end_date = parse_date(end_date_str)

                if start_date > end_date:
                    raise ValidationError("Start date cannot be after end date")
                
                diff_date = (end_date - start_date).days
                # print('start Date = ', start_date, 'end Date = ', end_date)
                # print('diff Date = ', diff_date)
            else:
                raise ValidationError("Both start date and end date must be provided")

            client_name = request.POST.get('client-id')
            # if client_name:
            #     print("client name = ", client_name)

            # Advertisement name
            ad_name = request.POST.get('ad-name').strip()
            if ad_name:
                pass
            else:
                return redirect('index')

            discountVal = request.POST.get('discount').strip()
            advanceAmtInput = request.POST.get('advance').strip()
            AdMakingChargeInput = request.POST.get('AdMakingCharge').strip()
            gst_check_input = request.POST.getlist('gst-option')

            discountInputVal = discountVal if discountVal else 0
            advanceAMT = advanceAmtInput if advanceAmtInput else 0
            adMakingCharge = AdMakingChargeInput if AdMakingChargeInput else 0

            gst_check_inputVal = None
            if gst_check_input:
                if len(gst_check_input) > 1:
                    # print("gst input val len', ", len(gst_check_input))
                    return redirect('index')
                else:
                    gst_check_inputVal = gst_check_input[0]
                    # print("gst input val', ", gst_check_inputVal)
            else:
                return redirect('index')

            # Calculate total charge
            adVal = float(adVal)  # Ensure adVal is a float for division
            totalChargeVal = len_of_selected_buses * (diff_date * adVal / 30)
            totalCharge = round(totalChargeVal, 2)
            # print("totalCharge = ", totalCharge)
           
            if discountInputVal:
                totalCharge =totalCharge-float(discountInputVal)
            else:
                 totalCharge=0   
            if advanceAMT:
                totalCharge = totalCharge- float(advanceAMT)
            else:
                totalCharge =0    
            if adMakingCharge:
                totalCharge =totalCharge + float(adMakingCharge)
            else:
                totalCharge =0     
            totalCharge = totalCharge
            # print('totalPay_after_adMakingCharge = ', totalCharge)
            
            totalCharge_show =round( totalCharge + float( advanceAMT))
            
            CreateOrder.objects.create(
                ad_capture_by_type=ad_capture_by_type,
                ad_capture_by_value=ad_capture_by_val,
                adVal=adVal,
                len_of_selected_buses=len_of_selected_buses,
                bus_type=bus_types,
                bus_fr_or_agency=bus_fr_or_agency,
                bus_owners=bus_owners,
                start_date=start_date,
                end_date=end_date,
                diff_date=diff_date,
                client_name=client_name,
                ad_name=ad_name,
                discount_amount=discountInputVal,
                gst_check_inputVal=gst_check_inputVal,
                advance_amount=advanceAMT,
                ad_making_charge=adMakingCharge,
                total_payable_amount=totalCharge,
                totalCharge_show=totalCharge_show,
            )
            return redirect('orders')

        except ValueError:
            error_message = "Invalid date format. Please use YYYY-MM-DD."
        except ValidationError as ve:
            error_message = str(ve)
        except Exception as e:
            error_message = "An unexpected error occurred: " + str(e)

    # Fetch data for initial form rendering
    iterRevenueFormula = RevenueFormula.objects.all().values()
    iterClients = Clients.objects.all()
    iterBuses = Buses.objects.all()
    iterAdsDurationVal = RevenueFormula.objects.all()
  
    context = {
        'iterRevenueFormula': iterRevenueFormula,
        'adsDurationValue': iterAdsDurationVal,
        "buses": iterBuses,
        "ad_capture_val": ad_capture_val,
        "ad_capture": ad_capture,
        "franchisee_options": list(franchisee_options.values('f_name')),
        "agency_options": list(agency_options.values('agencyName')),
        "iterClients": list(iterClients.values('name')),
        "error_message": error_message,
    }
    
    return render(request, 'index.html',context)

def orders (request):
    
    #take all data from createOrder Models
    order_data = CreateOrder.objects.all()
    
    
    ad_capture_by_type=None
    ad_capture_by_val=None
    adVal=None
    len_of_selected_buses=None
    bus_types=None
    bus_fr_or_agency=None
    start_date=None
    end_date=None
    diff_date=None
    client_name=None
    ad_name=None
    discount_amount =None
    gst_check_inputVal =None
    advance_amount =None
    ad_making_charge=None
    total_payable_amount =None
    for order in order_data:
        ad_capture_by_type = order.ad_capture_by_type
        ad_capture_by_val = order.ad_capture_by_value
        adVal = order.adVal
        len_of_selected_buses= order.len_of_selected_buses
        bus_types= order.bus_type
        bus_fr_or_agency=order.bus_fr_or_agency
        bus_owners = order.bus_owners
        start_date = order.start_date
        end_date=order.end_date
        diff_date= order.diff_date
        client_name = order.client_name
        ad_name = order.ad_name
        discount_amount=order.discount_amount
        gst_check_inputVal= order.gst_check_inputVal
        advance_amount = order.advance_amount
        ad_making_charge = order.ad_making_charge
        total_payable_amount= order.total_payable_amount
        
        
    #gst calculation
    gst_inclusive_amt = 0
    gst_exclusive_amt= 0
    # print(" before total_payable_amount",total_payable_amount) 
    total_payable=round( total_payable_amount - float(advance_amount) )
    total_with_gst = total_payable  
    gst_amt =float( round( total_payable *( 3.14/100))) 
    if gst_check_inputVal == 'inclusive':
        gst_inclusive_amt =  gst_amt 
        total_with_gst= total_with_gst - float(gst_inclusive_amt)
    elif gst_check_inputVal == 'exclusive':
        gst_exclusive_amt = gst_amt
        total_with_gst = total_with_gst+float( gst_exclusive_amt)
    
    # calculate selected according their order form id 
       
    
    dividend_amount = round( total_payable_amount - ad_making_charge)
    
    revenueFormula = RevenueFormula.objects.all()
    fr_normal= None
    bus_owner_normal= None
    organization_normal=None
    companyRevenue_normal= None
    
    ad_fr_other= None
    bus_fr_other= None
    bus_owner_other= None
    organization_other=None
    companyRevenue_other= None
    service_other=None
    
    
    ad_agency= None
    bus_fr_agency= None
    bus_owner_agency= None
    organization_agency=None
    companyRevenue_agency= None
    
    
    
    for formula in revenueFormula:
        fr_normal= formula.normal_franchisee
        bus_owner_normal= formula.normal_busOwner
        organization_normal=formula.normal_busOrganization
        companyRevenue_normal= formula.normal_company
        
        ad_fr_other= formula.other_fr_adFranchisee
        bus_fr_other= formula.other_fr_franchisee
        bus_owner_other= formula.other_fr_busOwner
        organization_other=formula.other_fr_busOrganization
        companyRevenue_other= formula.other_fr_company
        service_other = formula.other_fr_service
        
        ad_agency= formula.agency_agency
        bus_fr_agency= formula.agency_franchisee
        bus_owner_agency= formula.agency_bus_owner
        organization_agency=formula.agency_bus_organization
        companyRevenue_agency= formula.agency_company
    # print("dividend_amount",dividend_amount)    
    fr_normal=round( dividend_amount * (float(fr_normal/100)))
    # print("fr_normal",fr_normal)
    bus_owner_normal= round( dividend_amount * (bus_owner_normal/100))
    organization_normal= round( dividend_amount * (organization_normal/100))
    companyRevenue_normal= round( dividend_amount * (companyRevenue_normal/100))
    
    ad_fr_other= round( dividend_amount * (ad_fr_other/100))
    bus_fr_other= round( dividend_amount * (bus_fr_other/100))
    bus_owner_other= round( dividend_amount * (bus_owner_other/100))
    organization_other= round( dividend_amount * (organization_other/100))
    companyRevenue_other= round( dividend_amount * (companyRevenue_other/100))
    service_other= round( dividend_amount * (service_other/100))
    
    
    ad_agency= round( dividend_amount * (ad_agency/100))
    bus_fr_agency= round( dividend_amount * (bus_fr_agency/100))
    bus_owner_agency= round( dividend_amount * (bus_owner_agency/100))
    organization_agency=round( dividend_amount * (organization_agency/100))
    companyRevenue_agency= round( dividend_amount * (companyRevenue_agency/100))    
        
        
        
    
    
    #normal
    fr_matching_entries_normal = {}
    bus_owner_matching_entries_normal = {}
    organization_matching_entries_normal = {}
    companyRevenue_matching_entries_normal = {}
    
    # other
    bus_fr_other_entries = {}
    # add payment franchisee payment view
    ad_fr_other_entries = {}
    bus_owner_fr_other_entries = {}
    organization_fr_other_entries = {}
    companyRevenue_fr_other_entries = {}
    service_fr_other_entries = {}

    #agency
    agency_matching_entries = {}
    company_agency_matching_entries = {}
    bus_owner_agency_matching_entries = {}
    organization_agency_matching_entries = {}
    bus_franchisee_agency_matching_entries = {}
   
    start_date_str = start_date.strftime('%Y-%m-%d') if start_date else None
    end_date_str = end_date.strftime('%Y-%m-%d') if end_date else None
    if ad_capture_by_type =='franchisee':
        for id, role in bus_types.items():
            name = bus_fr_or_agency.get(id)
            bus_owner_name = bus_owners.get(id)
            if role == ad_capture_by_type:
                if role == ad_capture_by_type and name == ad_capture_by_val:
                     # apply normal formula
                    
                    fr_matching_entries_normal[id] = {'role': role, 'name': name,'ad_name':ad_name,'start_dates':start_date_str,"end_dates":end_date_str,"formula":"normal","amount":fr_normal,}
                    
                    bus_owner_matching_entries_normal[id] = {'bus_owner': bus_owner_name,'ad_name':ad_name,'start_dates':start_date_str,"end_dates":end_date_str,"formula":"normal","amount":bus_owner_normal}
                    
                    organization_matching_entries_normal[id] = {'name': name,'ad_name':ad_name,'start_dates':start_date_str,"end_dates":end_date_str,"formula":"normal","amount":organization_normal}
                     
                    companyRevenue_matching_entries_normal[id] = {'ad_name':ad_name,'start_dates':start_date_str,"end_dates":end_date_str,"formula":"normal","amount":companyRevenue_normal}
                   
            else:
                ad_fr_other_entries[id] = {'role': role, 'name': name,'ad_name':ad_name,'start_dates':start_date_str,"end_dates":end_date_str,"formula":"ad_franchisee","amount":ad_fr_other}
                
                bus_fr_other_entries[id] = {'role': role, 'name': name,'ad_name':ad_name,'start_dates':start_date_str,"end_dates":end_date_str,"formula":"bus_franchisee","amount":bus_fr_other}
                
                bus_owner_fr_other_entries[id] = {'bus_owner': bus_owner_name,'ad_name':ad_name,'start_dates':start_date_str,"end_dates":end_date_str,"formula":"other_franchisee","amount":bus_owner_other}
                
                organization_fr_other_entries[id] = {'name': name,'ad_name':ad_name,'start_dates':start_date_str,"end_dates":end_date_str,"formula":"other_franchisee","amount":organization_other}
                
                companyRevenue_fr_other_entries[id] = {'ad_name':ad_name,'start_dates':start_date_str,"end_dates":end_date_str,"formula":"other franchisee","amount":companyRevenue_other}
                
                service_fr_other_entries[id] = {'ad_name':ad_name,'start_dates':start_date_str,"end_dates":end_date_str,"formula":"other_franchisee","amount":service_other}
                  
        #apply other franchisee formula 'name': name  is bus franchisee or other franchisee and # # #ad_capture_by_val is franchisee share

    else:
        for id, role in bus_types.items():
            name = bus_fr_or_agency.get(id)
            bus_owner_name = bus_owners.get(id)
            if role == ad_capture_by_type :
                agency_matching_entries[id] = {'ad_name':ad_name,'start_dates':start_date_str,"end_dates":end_date_str,"formula":"agency","amount":ad_agency}
                
                bus_franchisee_agency_matching_entries[id] = {'ad_name':ad_name,'start_dates':start_date_str,"end_dates":end_date_str,"formula":"agency","amount":bus_fr_agency}
                
                company_agency_matching_entries[id] = {'ad_name':ad_name,'start_dates':start_date_str,"end_dates":end_date_str,"formula":"agency","amount":companyRevenue_agency}
                
                bus_owner_agency_matching_entries[id] = {'bus_owner': bus_owner_name,'ad_name':ad_name,'start_dates':start_date_str,"end_dates":end_date_str,"formula":"agency","amount":bus_owner_agency}
                
                organization_agency_matching_entries[id] = {'name': name,'ad_name':ad_name,'start_dates':start_date_str,"end_dates":end_date_str,"formula":"agency","amount":bus_owner_agency}
                
    #apply this 'role': role, 'name': name for bus franchisee and  ad_capture_by_val is agency


    total_payable_amount_show=0
    if request.method =='POST':
        if 'ad-payment' in request.POST and 'match_order_id' in request.POST: 
            ad_payment_installment = request.POST.get('ad-payment')
            invoices_number = request.POST.get('invoice-number')
            match_order_id= request.POST.get('match_order_id')
            # print('match =',match_order_id)
            #Ensure ad_payment_installment is converted to float
            try:
                ad_payment_installment = float(ad_payment_installment)
            except ValueError:
                return HttpResponse('Invalid ad_payment value.')

            try:
                # Retrieve the order object
                order = CreateOrder.objects.get(id=match_order_id)        
                # Create and save a new installmentsPayment object
                current_date = timezone.now().date()
                strCurrentDate =str( current_date)
                saveInstallPaymentPay = installmentsPayment.objects.create(
                    ad_payment=ad_payment_installment,
                    invoices_number=invoices_number,
                    order_id=match_order_id,
                    date=strCurrentDate,
                )
                # print('current date', current_date)
                # print(type( current_date))
                #Update advance_amount in the order object
                saveInstallPaymentPay.save()
                if order.advance_amount is None:
                    order.advance_amount = 0
                order.advance_amount += round(ad_payment_installment)
                order.save()
                
                # Redirect or return a response
                return redirect('orders')

            except CreateOrder.DoesNotExist:
                return HttpResponse(f"Order with ID {match_order_id} does not exist.")
        else:    
 
            saveCollectData = CollectData.objects.create(fr_matching_entries_normal=fr_matching_entries_normal,bus_owner_matching_entries_normal=bus_owner_matching_entries_normal,organization_matching_entries_normal=organization_matching_entries_normal,companyRevenue_matching_entries_normal=companyRevenue_matching_entries_normal,bus_fr_other_entries=bus_fr_other_entries,ad_fr_other_entries=ad_fr_other_entries,bus_owner_fr_other_entries=bus_owner_fr_other_entries,organization_fr_other_entries=organization_fr_other_entries,companyRevenue_fr_other_entries=companyRevenue_fr_other_entries,service_fr_other_entries=service_fr_other_entries,agency_matching_entries=agency_matching_entries,company_agency_matching_entries=company_agency_matching_entries,bus_owner_agency_matching_entries=bus_owner_agency_matching_entries,organization_agency_matching_entries=organization_agency_matching_entries,bus_franchisee_agency_matching_entries=bus_franchisee_agency_matching_entries)
    
            saveCollectData.save()
            saveGst = GstPayment.objects.create(client_name=client_name,ad_name=ad_name,taxable_amount=total_payable,Gst_amount=gst_amt,total_amount_with_gst=gst_inclusive_amt,status='pending',actions="mark payment complete")        
            saveGst.save() 
            return redirect('index')
            # print(saveCollectData)
              
    iterSaveInstallPaymentPay= installmentsPayment.objects.all()
    total_payable_amount_show = total_payable_amount + advance_amount           
    context ={
        'saveInstallPaymentPay':iterSaveInstallPaymentPay,
        'total_payable_amount_show':total_payable_amount_show,
        'create_orders':order_data,
        # 'order_data_collection':order_data_collection,
    }    
    
    return render(request, 'orders.html',context)

def deleteOrders(request,order_id):
    order_form = CreateOrder.objects.filter(id=order_id)[0]
    order_form.delete()
    return redirect('orders')
    
def franchisees (request):

    if request.method == 'POST':
        
        f_code = request.POST.get('f_code')
        f_name = request.POST.get('f_name')
        f_phone = request.POST.get('f_phone')
        f_address = request.POST.get('f_address')
        if f_code and f_name and f_phone and f_address:
            check_franchisees_code = Franchisees.objects.filter(f_code=f_code)
            check_franchisees_phn_no = Franchisees.objects.filter(f_phone_number=f_phone)
            if check_franchisees_code or check_franchisees_phn_no:
                return redirect("franchisees")
            else:
                con = Franchisees.objects.create(f_code=f_code, f_name=f_name, f_phone_number=f_phone, f_address=f_address)
                con.save()
    iterFranchisees = Franchisees.objects.all().values()
    context = {
        'franchisees': iterFranchisees
    }
    return render(request, 'franchisee.html', context)

def delete_franchisee(request, franchisee_code):
    franchisee = Franchisees.objects.filter(f_code=franchisee_code)[0]
    franchisee.delete()
    return redirect('franchisees')



def franchiseePaymentView(request, franchisee_name):
    # print("Franchisee Name:", franchisee_name)
    franchisee_name_show = franchisee_name
    # Get all CollectData objects
    collect_data = CollectData.objects.all()
    
    # Initialize empty lists to store filtered data
    fr_filtered_data = []
    other_fr_filtered_data = []
    bus_fr_filtered_data = []
    
    # Iterate over all CollectData objects
    for data in collect_data:
        # print(f"Processing CollectData ID: {data.id}")
        
        # Access the fr_matching_entries_normal dictionary
        matching_entries = data.fr_matching_entries_normal
        other_entries = data.ad_fr_other_entries
        bus_entries = data.bus_fr_other_entries
        
        # print("Matching Entries:", matching_entries)
        # print("Other Entries:", other_entries)
        
        # Filter the entries based on the franchisee name
        filtered_entries = {key: value for key, value in matching_entries.items() if value.get('name') == franchisee_name}
        other_filtered_entries = {key: value for key, value in other_entries.items() if value.get('name') != franchisee_name}
        bus_filtered_entries = {key: value for key, value in other_entries.items() if value.get('name') != franchisee_name}
        
        # print("Filtered Entries:", filtered_entries)
        # print("Other Filtered Entries:", other_filtered_entries)
        
        # If there are any filtered entries, add to the result list
        if filtered_entries:
            fr_filtered_data.append({
                'id': data.id,
                'filtered_entries': filtered_entries
            })
        
        if other_filtered_entries:
            other_fr_filtered_data.append({
                'id': data.id,
                'filtered_entries': other_filtered_entries
            })
        if bus_filtered_entries:
            bus_fr_filtered_data.append({
                'id': data.id,
                'filtered_entries': other_filtered_entries
            })
    
    # Iterate over filtered data and extract required fields
    fr_extracted_data = []
    other_fr_extracted_data = []
    bus_fr_extracted_data = []
    for entry in fr_filtered_data:
        for key, value in entry['filtered_entries'].items():
            fr_extracted_data.append({
                'id': entry['id'],
                'name': value.get('name'),
                'ad_name': value.get('ad_name'),
                'start_dates': value.get('start_dates'),
                'end_dates': value.get('end_dates'),
                'formula': value.get('formula'),
                'amount': value.get('amount')
            })
    
    for entry in other_fr_filtered_data:
        for key, value in entry['filtered_entries'].items():
            other_fr_extracted_data.append({
                'id': entry['id'],
                'name': value.get('name'),
                'ad_name': value.get('ad_name'),
                'start_dates': value.get('start_dates'),
                'end_dates': value.get('end_dates'),
                'formula': value.get('formula'),
                'amount': value.get('amount')
            })
    for entry in bus_fr_filtered_data:
        for key, value in entry['filtered_entries'].items():
            bus_fr_extracted_data.append({
                'id': entry['id'],
                'name': value.get('name'),
                'ad_name': value.get('ad_name'),
                'start_dates': value.get('start_dates'),
                'end_dates': value.get('end_dates'),
                'formula': value.get('formula'),
                'amount': value.get('amount')
            })
    
   
    return render(request, 'franchiseePaymentView.html', {'fr_extracted_data': fr_extracted_data, 'other_fr_extracted_data': other_fr_extracted_data,'franchisee_name_show':franchisee_name_show,'bus_fr_extracted_data':bus_fr_extracted_data,})



def client (request):
    if request.method =="POST":
        c_name = request.POST.get('c_name')
        c_email = request.POST.get('c_email')
        c_phone = request.POST.get('c_phone')
        c_address = request.POST.get('c_address')
        c_gst = request.POST.get('c_gst')
        
        if c_name and c_email and c_phone and c_address and c_gst :
            check_cName =Clients.objects.filter(name=c_name)
            check_cEmail =Clients.objects.filter(email=c_email)
            check_cPhone =Clients.objects.filter(phone=c_phone)
            check_cAddress =Clients.objects.filter(address=c_address)
            if check_cName and check_cEmail and check_cPhone and check_cAddress:
                return redirect('client')
            else:
                con = Clients.objects.create(name=c_name, email=c_email, phone=c_phone,address = c_address,gst=c_gst)
                con.save()
    
    return render(request, 'client.html',{})

def clientViews (request):
    iterClients = Clients.objects.all()
    return render(request, 'clientViews.html',{"clients":iterClients})


def deleteClient(request, client_name):
    deleteClient = Clients.objects.filter(name=client_name)[0]
    deleteClient.delete()
    return redirect('clientViews')

def buses(request):
    bus_capture = "franchisee"
    franchisee_options = Franchisees.objects.all()
    agency_options = Agency.objects.all()
    bus_capture_val = franchisee_options  # Default to franchisees

    if request.method == "POST":
        bus_capture_by_type = request.POST.get('bus-captured-by-type')
        bus_captured_by_id = request.POST.get('bus-captured-by-id')
        bus_name = request.POST.get('bus-name')
        district = request.POST.get('district')
        owner_name = request.POST.get('owner-name')
        bus_route = request.POST.get('bus-route')
        vehicle_number = request.POST.get('vehicle-number')
        
        if bus_capture_by_type == 'franchisee':
            bus_capture = "franchisee"
            bus_capture_val = franchisee_options
        elif bus_capture_by_type == 'agency':
            bus_capture = "agency"
            bus_capture_val = agency_options
            print("Agency is selected")
        
        con = Buses.objects.create(
            franchisee_Or_agency=bus_capture,
            captured_type_value=bus_captured_by_id,
            bus_name=bus_name,
            district=district,
            owner_name=owner_name,
            bus_route=bus_route,
            vehicle_number=vehicle_number
        )
        con.save()
        
        return redirect('buses')  # Redirect to the same page to prevent re-submission

    context = {
        
        "bus_capture_val": bus_capture_val,
        "bus_capture": bus_capture,
        "franchisee_options": list(franchisee_options.values('f_name')),  # Pass only necessary fields
        "agency_options": list(agency_options.values('agencyName')),    # Pass only necessary fields
    }
    return render(request, 'buses.html', context)

def busesListView (request):
    iterBuses = Buses.objects.all()
   
    return render(request, 'busesListView.html',{'buses':iterBuses})

from django.shortcuts import render
from .models import CollectData

def paymentBusesListView(request, bus_owner_name):
    # Get all CollectData objects
    collect_data = CollectData.objects.all()
    
    # Initialize lists to store filtered data
    normal_extracted_data = []
    other_extracted_data = []
    agency_extracted_data = []

    for data in collect_data:
        matching_entries = data.bus_owner_matching_entries_normal
        other_entries = data.bus_owner_fr_other_entries
        agency_entries = data.bus_owner_agency_matching_entries
        
        # Filter entries for normal bus owners
        for key, value in matching_entries.items():
            if value.get('bus_owner') == bus_owner_name:
                normal_extracted_data.append({
                    'id': key,
                    'bus_owner': value.get('bus_owner'),
                    'ad_name': value.get('ad_name'),
                    'start_dates': value.get('start_dates'),
                    'end_dates': value.get('end_dates'),
                    'formula': value.get('formula'),
                    'amount': value.get('amount')
                })

        # Filter entries for other bus owners
        for key, value in other_entries.items():
            if value.get('bus_owner') == bus_owner_name:
                other_extracted_data.append({
                    'id': key,
                    'bus_owner': value.get('bus_owner'),
                    'ad_name': value.get('ad_name'),
                    'start_dates': value.get('start_dates'),
                    'end_dates': value.get('end_dates'),
                    'formula': value.get('formula'),
                    'amount': value.get('amount')
                })

        # Filter entries for agency bus owners
        for key, value in agency_entries.items():
            if value.get('bus_owner') == bus_owner_name:
                agency_extracted_data.append({
                    'id': key,
                    'bus_owner': value.get('bus_owner'),
                    'ad_name': value.get('ad_name'),
                    'start_dates': value.get('start_dates'),
                    'end_dates': value.get('end_dates'),
                    'formula': value.get('formula'),
                    'amount': value.get('amount')
                })
    
    print(normal_extracted_data)
    # Render the template with extracted data
    return render(request, 'paymentBus.html', {
        'normal_extracted_data': normal_extracted_data,
        'other_extracted_data': other_extracted_data,
        'agency_extracted_data': agency_extracted_data
    })


def extract_entries(entries):
    extracted_data = []
    for key, value in entries.items():
        extracted_data.append({
            'id': key,
            'name': value.get('name'),
            'ad_name': value.get('ad_name', ''),
            'start_dates': value.get('start_dates', ''),
            'end_dates': value.get('end_dates', ''),
            'formula': value.get('formula', ''),
            'amount': value.get('amount', 0)
        })
    return extracted_data

def organization(request):
    # Get all CollectData objects
    collect_data_list = CollectData.objects.all()
    
    # Initialize lists to store filtered data
    normal_extracted_data = []
    other_extracted_data = []
    agency_extracted_data = []

    for collect_data in collect_data_list:
        # Extract and append data for normal bus owners
        normal_extracted_data.extend(extract_entries(collect_data.companyRevenue_matching_entries_normal))

        # Extract and append data for other bus owners
        other_extracted_data.extend(extract_entries(collect_data.companyRevenue_fr_other_entries))

        # Extract and append data for agency bus owners
        agency_extracted_data.extend(extract_entries(collect_data.company_agency_matching_entries))
    
    # print(normal_extracted_data)
    # print(other_extracted_data)
    # print(agency_extracted_data)
    
    return render(request, 'organisation.html', {
        'normal_extracted_data': normal_extracted_data,
        'other_extracted_data': other_extracted_data,
        'agency_extracted_data': agency_extracted_data
    })


def gst (request):
    iterGst = GstPayment.objects.all()  
    return render(request, 'gst.html',{'iterGst':iterGst})


def companyRevenue (request):
    # Get all CollectData objects
    collect_data_list = CollectData.objects.all()
    
    # Initialize lists to store filtered data
    normal_extracted_data = []
    other_extracted_data = []
    agency_extracted_data = []

    for collect_data in collect_data_list:
        # Extract and append data for normal bus owners
        normal_extracted_data.extend(extract_entries(collect_data.companyRevenue_matching_entries_normal))

        # Extract and append data for other bus owners
        other_extracted_data.extend(extract_entries(collect_data.companyRevenue_fr_other_entries))

        # Extract and append data for agency bus owners
        agency_extracted_data.extend(extract_entries(collect_data.company_agency_matching_entries))
    return render(request, 'companyRevenue.html',{
        'normal_extracted_data': normal_extracted_data,
        'other_extracted_data': other_extracted_data,
        'agency_extracted_data': agency_extracted_data
    })


def serviceCharge (request):
      # Get all CollectData objects
    collect_data_list = CollectData.objects.all()
    
    # Initialize lists to store filtered data
    normal_extracted_data = []
    other_extracted_data = []
    agency_extracted_data = []

    for collect_data in collect_data_list:

        # Extract and append data for other bus owners
        other_extracted_data.extend(extract_entries(collect_data.service_fr_other_entries))

    
    # print(normal_extracted_data)
    # print(other_extracted_data)
    # print(agency_extracted_data)
    return render(request, 'serviceCharge.html',{
        'other_extracted_data':other_extracted_data
    })


def companyAsAgency (request):
    if request.method == 'POST':
        agency_name = request.POST.get('agency_name')
        if agency_name is None:
            return redirect('companyAsAgency')
        else:
            checkAgency_name = Agency.objects.filter(agencyName=agency_name)
            if checkAgency_name:
                return redirect('companyAsAgency')
            else:
                con = Agency.objects.create(agencyName=agency_name)
                con.save()
    iterAgency = Agency.objects.all().values()  
    return render(request, 'companyAsAgency.html',{'agencies':iterAgency})

def deleteAgency(request,agency_name):
    checkData = Agency.objects.all().values()
    
    if checkData:
        checkAgency_name = Agency.objects.filter(agencyName=agency_name)[0]
        checkAgency_name.delete()
        return redirect('companyAsAgency')   
    else:
        return redirect('companyAsAgency')    

    return render(request, 'companyAsAgency.html',{})
        
def agencyPaymentsView(request):
    return render(request, 'agencyPaymentsView.html',{})
    
    
def revenueFormula (request):
    if request.method == 'POST':
        normal_company = request.POST.get('normal--company')
        normal_busOwner = request.POST.get('normal--bus-owner')
        normal_busOrganization = request.POST.get('normal--bus-organisation')
        normal_franchisee = request.POST.get('normal--franchisee')
        
        other_fr_company = request.POST.get('other-fr--company')
        other_fr_adFranchisee = request.POST.get('other-fr--ad-franchisee')
        other_fr_busOwner = request.POST.get('other-fr--bus-owner')
        other_fr_busOrganization = request.POST.get('other-fr--bus-organization')
        other_fr_franchisee = request.POST.get('other-fr--franchisee')
        other_fr_service = request.POST.get('other-fr--server')
        
        agency_company = request.POST.get('agency--company')
        agency_bus_owner = request.POST.get('agency--bus-owner')
        agency_bus_organization = request.POST.get('agency--bus-organization')
        agency_franchisee = request.POST.get('agency--franchisee')
        agency_agency = request.POST.get('agency--agency')
        
        duration15s = request.POST.get('duration15s')
        duration30s = request.POST.get('duration30s')
        duration45s = request.POST.get('duration45s')
        duration60s = request.POST.get('duration60s')
        
        if normal_busOwner and normal_company and normal_busOrganization and normal_franchisee and other_fr_company and other_fr_adFranchisee and other_fr_busOwner and other_fr_busOrganization and other_fr_franchisee and other_fr_service and agency_company and agency_bus_owner and agency_bus_organization and agency_franchisee and agency_agency:
            
            saveRevenueFormula = RevenueFormula.objects.create(normal_company=normal_company,normal_busOwner=normal_busOwner,normal_busOrganization=normal_busOrganization,normal_franchisee=normal_franchisee,other_fr_company=other_fr_company,other_fr_adFranchisee=other_fr_adFranchisee,other_fr_busOwner=other_fr_busOwner,other_fr_busOrganization=other_fr_busOrganization,other_fr_franchisee=other_fr_franchisee,other_fr_service=other_fr_service,agency_company=agency_company,agency_bus_owner=agency_bus_owner,agency_bus_organization=agency_bus_organization,agency_franchisee=agency_franchisee,agency_agency=agency_agency,duration15s=duration15s,duration30s=duration30s,duration45s=duration45s,duration60s=duration60s)
            
            saveRevenueFormula.save()
        else:
            return redirect('revenueFormula')        
        
        
    return render(request, 'revenueFormula.html',{})
